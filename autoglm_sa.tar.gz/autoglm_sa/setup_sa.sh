#!/bin/bash
# AutoGLM South Africa Edition - Setup Script
echo "🇿🇦 Setting up AutoGLM for South Africa..."

# Check system requirements
echo "🔍 Checking system requirements..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    exit 1
fi

# Install dependencies
echo "📦 Installing Python dependencies..."
pip3 install -r requirements.txt

# Check for local model
if [ -d "models/autoglm-phone-9b-multilingual" ]; then
    echo "✅ Local model found - offline mode available"
    MODEL_MODE="local"
else
    echo "🌐 No local model - using cloud mode"
    MODEL_MODE="cloud"
fi

# Create configuration
echo "⚙️ Creating configuration..."
cat > config.json << EOF
{
    "mode": "$MODEL_MODE",
    "region": "south_africa",
    "setup_date": "$(date)",
    "version": "1.0"
}
EOF

echo "✅ AutoGLM setup completed!"
echo "🚀 Run './start_autoglm.sh' to begin"
