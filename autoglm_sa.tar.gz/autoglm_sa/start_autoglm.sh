#!/bin/bash
# AutoGLM South Africa Edition - Start Script
echo "🤖 Starting AutoGLM South Africa Edition..."

# Load configuration
if [ -f "config.json" ]; then
    MODE=$(grep -o '"mode": "[^"]*"' config.json | cut -d'"' -f4)
else
    MODE="cloud"
fi

# Start AutoGLM based on mode
if [ "$MODE" = "local" ]; then
    echo "🏠 Starting in local mode..."
    python3 main.py --base-url http://localhost:8000/v1 --model autoglm-phone-9b-multilingual
else
    echo "☁️ Starting in cloud mode..."
    python3 main.py --base-url https://api.z.ai/api/paas/v4 --model autoglm-phone-multilingual
fi
